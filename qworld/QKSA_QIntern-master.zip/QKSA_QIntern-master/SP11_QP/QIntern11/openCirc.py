'''
Task 5: 
Write a program to take a probabilistic ensemble and return the Choi matrix of the process. 
For each qcirc_obj, use the Qiskit's Choi function to retrive the process, and the aggregate them based on the probabilities.

Task 6: 
Write a program to take a Choi matrix and an input density matrix and return the output density matrix. 
Use this code to test the implementation of task 5 by 1st) individually creating the Choi matrix of the array of circuits, arregating the output density matrix for a input density matrix; 2nd) using the arregated Choi matrix to get the output density matrix; 3rd) comparing they are the same. 
You can use any input density matrix you wish (e.g. define any 1-qubit quantum circuit and use the qiskit qi package to get the density matrix). 
Use https://github.com/Advanced-Research-Centre/QKSA/blob/main/legacy_vers/v12/sandbox/aaqpt.py to understand how a Choi matrix works.

Task 7: 
An open QC can also consist of measurement gates. 
Currently Qiskit does not allow specifying a measurement within a custom gate (to_gate command). 
Find a way to embed a specified quantum circuit (with measurement gate) as part of a larger quantum circuit. 
E.g. say a quantum circuit object A consists of 1 qubit and 1 cbit, with a hadamard and a measurement. 
If A is passed to the function, the function adds a hadamard before A and another measurement after A.
'''

# Task 5

from qiskit import *

def calcChoi(qp, trials = 1000):
	tot_prob = 0
	choi = 0
	for qpi in qp:
		choi_part = quantum_info.Choi(qpi[1]).data / 2
		tot_prob += qpi[0]
		choi += qpi[0]*choi_part
	if (tot_prob < 1):
		choi += (1-tot_prob)*(eye(4)/4)
	return choi

p1 = 0.5
c1 = QuantumCircuit(1,1)
c1.x(0)

p2 = 0.1
c2 = QuantumCircuit(1,1)
c2.y(0)

p3 = 0.4
c3 = QuantumCircuit(1,1)
c3.z(0)

qp = []
qp.append([p1,c1])
qp.append([p2,c2])
qp.append([p3,c3])

choi = calcChoi(qp, 100)
print(choi)