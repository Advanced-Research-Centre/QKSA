import matplotlib.pyplot as plt
from qiskit import*

def and_gate(qc, a, b, c):
    qc.ccx(a, b, c)

def or_gate(qc, a, b, c):
    qc.cx(a, c)
    qc.cx(b, c)
    qc.ccx(a, b, c)

def not_gate2(qc, a):
    qc.x(a)

def not_gate1(qc, a, b):
    qc.x(b)
    qc.cx(a, b)

#Precedence of operators defined for shunting yard
def precedence(a):
    if (a == "+"):
        return 1
    elif (a == "*"):
        return 2
    elif (a == "!"):
        return 3



def boolean_to_qc(string):
    
    #Shunting yard algorithm out_queue gives desired output as a list
    op_stack = []
    out_queue = []
    num_input = 0
    num_ancilla = 0
    for ch in string:
        if (ch.isnumeric()):
            if(int(ch) > num_input):
                num_input = int(ch)
            out_queue.append(str(ch))
        elif (ch == "("):
            op_stack.append(ch)
        elif (ch == ")"):
            while (op_stack[-1] != '('):
                out_queue.append(op_stack.pop())
            op_stack.pop()
        else: 
            num_ancilla += 1
            while((len(op_stack) != 0) and (op_stack[-1] != "(") and ( precedence(ch) <= precedence(op_stack[-1]))):
                out_queue.append(op_stack.pop())
            op_stack.append(ch)

    while (len(op_stack) != 0):
        out_queue.append(op_stack.pop())
    num_input += 1

    q_n = QuantumRegister(num_input,name ='input')
    q_a = QuantumRegister(num_ancilla,name ='ancilla')
    
    #Quantum Circuit implementation
    qc = QuantumCircuit(q_n,q_a)
    ancilla = num_input
    eval_stack = []
    for i in out_queue:
        if(i.isnumeric()):
            eval_stack.append(int(i))
        elif(i == "*"):
            and_gate(qc, eval_stack.pop(), eval_stack.pop(), ancilla)
            eval_stack.append(ancilla)
            ancilla += 1
        elif(i == "+"):
            or_gate(qc, eval_stack.pop(), eval_stack.pop(), ancilla)
            eval_stack.append(ancilla)
            ancilla += 1
        elif(i == "!"):
            not_gate1(qc, eval_stack.pop(), ancilla)
            eval_stack.append(ancilla)
            ancilla += 1
    return qc
#When using variables start from 0 and go sequential
#For example if you have 3 variables use 0,1,2 as variable names
#Can be corrected in the future
string = "(!1+!0)*(!0+!1)"

qc = boolean_to_qc(string)
qc.draw('mpl')
plt.show()
