from qiskit import *
import matplotlib.pyplot as plt

""" 0 is 00c, 1 is 01c, 2 is 0bc, 3 is 10c, 4 is 11c, 5 is 1bc, 6 is a0c, 7 is a1c, 8 is abc"""

def one_tofolli(i):
    constants = QuantumRegister(4, name="constants")
    a = QuantumRegister(1, name="a")
    b = QuantumRegister(1, name="b")
    c = QuantumRegister(1, name="c")


    qc = QuantumCircuit(a, b, constants, c)
    qc.x(constants[1])
    qc.x(constants[3])

    if (i==0):
        qc.ccx(constants[0], constants[2], c)
    elif (i==1):
        qc.ccx(constants[0], constants[1], c)
    elif (i==2):
        qc.ccx(constants[0], b, c)
    elif (i==3):
        qc.ccx(constants[1], constants[2], c)
    elif (i==4):
        qc.ccx(constants[1], constants[3], c)
    elif (i==5):
        qc.ccx(constants[1], b, c)
    elif (i==6):
        qc.ccx(a, constants[0], c)
    elif (i==7):
        qc.ccx(a, constants[1], c)
    elif(i==8):
        qc.ccx(a, b, c)
    
    qc.draw('mpl')
    plt.show()

one_tofolli(0)