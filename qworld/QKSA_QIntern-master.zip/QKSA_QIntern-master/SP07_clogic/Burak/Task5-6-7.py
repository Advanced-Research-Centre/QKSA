from random import randint
from qiskit import *
from math import sqrt


sim = Aer.get_backend('aer_simulator')
#Dual input system whole 16 functions
def random_func_dual_input(qc, for_debug):
    #value = randint(0, 15)
    value = for_debug
    if(value == 0):
        #constant 0 function
        pass
    elif(value == 1):
        #constant 1 function
        qc.x(2)
    elif(value == 2):
        #pass value of first qubit
        qc.cx(0,2)
    elif(value == 3):
        #pass value of second qubit
        qc.cx(1,2)
    elif(value == 4):
        #pass negated value of first qubit
        qc.cx(0,2)
        qc.x(2)
    elif(value == 5):
        #pass negated value of second qubit
        qc.cx(1,2)
        qc.x(2)
    elif(value == 6):
        #And function
        qc.ccx(0,1,2)
    elif(value == 7):
        #Nand function
        qc.ccx(0,1,2)
        qc.x(2)
    elif(value == 8):
        #Or function
        qc.cx(0,2)
        qc.cx(1,2)
        qc.ccx(0,1,2)
    elif(value == 9):
        #Nor function
        qc.cx(0,2)
        qc.cx(1,2)
        qc.ccx(0,1,2)
        qc.x(2)
    elif(value == 10):
        #0 implies 1 function
        qc.x(2)
        qc.cx(0,2)
        qc.ccx(0,1,2)
    elif(value == 11):
        # 0 implies 1 negated function
        qc.cx(0,2)
        qc.ccx(0,1,2)
    elif(value == 12):
        # 1 implies 0 function
        qc.x(2)
        qc.cx(1,2)
        qc.ccx(0,1,2)
    elif(value == 13):
        # 1 implies 0 negated function
        qc.cx(1,2)
        qc.ccx(0,1,2)
    elif(value == 14):
        #Xor function
        qc.cx(0,2)
        qc.cx(1,2)
    else:
        #XNor function
        qc.cx(0,2)
        qc.cx(1,2)
        qc.x(2)



for i in range(16):
    qubit0 = [sqrt(2/3), sqrt(1/3)]
    qubit1 = [2/sqrt(5), sqrt(1/5)]

    q_input = QuantumRegister(2, name="a")
    q_result = QuantumRegister(1, name="c")

    qc = QuantumCircuit(q_input, q_result)

    qc.initialize(qubit0, 0)
    qc.initialize(qubit1, 1)
    random_func_dual_input(qc, i)
    qc.save_statevector()
    qobj = assemble(qc)
    state = sim.run(qobj).result().get_statevector() # Execute the circuit
    results = [0, 0]           # Print the result
    
    for j in range(4):
        results[0] += state[j] * state[j]
    for j in range(4, 8):
        results[1] += state[j] * state[j]

    results[0] = results[0].real
    results[1] = results[1].real
    print("Function number of "+ str(i))
    print(results)

"""For task 7 every function in my distribution has different output distribution If we manage to find a partition for input s.t any 3-1 and 2-2 addition of it is
not equal distribution wikk be different. It answers task 6 also """