import matplotlib.pyplot as plt
from qiskit import *
from random import randint

def random_func(qc):
    value = randint(0, 3)
    if(value == 0):
        #constant 0 function
        pass
    elif(value == 1):
        #constant 1 function
        qc.x(1)
    elif(value == 2):
        #identity function
        qc.cx(0, 1)
    else:
        #not function
        qc.cx(0, 1)
        qc.x(1)


A = QuantumRegister(1, name="a")
C = QuantumRegister(1, name="c")
result = ClassicalRegister(1, name="result")
qc = QuantumCircuit(A, C, result)
qc.h(A)
random_func(qc)
qc.measure(C, result)

#qc.draw('mpl')
#plt.show()


job = execute(qc,Aer.get_backend('qasm_simulator'),shots=1024)
observation = job.result().get_counts(qc)

if '0' in observation.keys():
    if observation['0'] == 1024:
        print("Constant 0 function")
    else:
        print("Either identity or not function")
else:
    print("Constant 1 function")

 