import matplotlib.pyplot as plt
from qiskit import*
""" We can say that since qiskit initilizes qubits to zero if our control qubit is low(zero) we do nothing to ancilla(output) qubit
 and we get |0> as output. If control qubit is high we apply nand gate to a equal superposed 2 qubit i.e 1/2|00> + 1/2|01> + 1/2|10> + 1/2|11>
 as a result we get 1/2|0>(from term 4) + sqrt(3)|1>(from term 1,2,3) so with 0.75 prob we get 1, 0.25 prob we get 0.
"""



def nand_gate(qc, a, b, c):
    qc.ccx(a, b, c)
    qc.x(c)
    
qc1 = QuantumCircuit(3)
nand_gate(qc1, 0, 1, 2)
controlled_nand_gate = qc1.to_gate().control(1)

q_n = QuantumRegister(2, name='input')
q_c = QuantumRegister(1, name='control')
q_r = QuantumRegister(1, name='qresult')
c_r = ClassicalRegister(1, name='cresult')

qc2 = QuantumCircuit(q_n, q_r, q_c, c_r)

qc2.x(q_c) #Make control qubit high
qc2.h(q_n)
qc2.append(controlled_nand_gate, [3, 0, 1, 2])

qc2.measure(q_r, c_r)

job = execute(qc2,Aer.get_backend('qasm_simulator'),shots=1024)
observation = job.result().get_counts(qc2)
print(observation)









