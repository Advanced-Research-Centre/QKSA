**Project: QKSA: Quantum Knowledge Seeking Agent**

**Mentor:** Aritra Sarkar

**Description:** 
Reinforcement Learning Agent for Quantum Foundations: The project involves using a universal AGI RL framework for simple experiments in QIT. The agents interact with the environment to model the quantum observables.

**Sub-projects and team members**

* SP01_readthedocs 
	* Tasbiha Asim `@Tasbiha Asim#8129`
	* Aleksandra Kowalczuk `@Aleksandra Kowalczuk#7438`                                    
* SP02_ux
	* Muhammed Adhil Pt `@Adhil#2211` 
* SP03_survey
	* Tamal Acharya `@Tamal_Acharya(He/Him!)#3293` :black_nib:
	* Muhammad Usaid `@Usaid#1941` :black_nib:
	* Prachi Agrawal `@prachi agrawal#9268` :black_nib:
* SP04_alife (quine hypervisor)
	* Dhanvanth Balakrishnan `@Dhanvanth B#5118` :black_nib:
	* Surya Venkatesh Embar `@Surya Embar (he/his)#7800`
* SP05_games (tic-tac-toe)
	* Santanu Banerjee `@santanubanerjee#3199` :black_nib:
	* Soham Bopardikar `@sohamb172#0138` :black_nib: 
* SP06_cworld (grid navigation)
	* Siddharth Golecha `@Siddharth Golecha#1962` :black_nib:
* SP07_clogic (Boolean logic learning)
	* Tan Jun Liang `@Jun Liang Tan#4881`
	* Bao Bach `@bbace#5583` :black_nib: :trophy:
	* Burak Uçar `@300#0446` :black_nib: :trophy:
	* Hirokjyoti Dutta `@HirokjyotiDutta#5559`
* SP08_least (Pebbling game and E-metric)
	* Aniruddha Sharma `@Yagami1729#8179`
	* Sarang Gosavi `@Sarang G#8745` :black_nib:
* SP09_qThought
	* Swaraj Purohit `@anomiusavvy#8821` :black_nib:
	* Prateek Jain `@Prateek Jain#5636` :black_nib:
	* Mostafa Shabani `@Mostafa#5738`
	* Kashish Goel `@Kashish Goel#1254` 
* SP10_QKSAs (multi-agent QPT)
	* Anaida Ali `@Anaida Ali#2041`
	* Arnav Arora `@eigen_arnav#0586` :black_nib:
	* Parv Bharagva `@RedShift#0865` :black_nib:
* SP11_QP (qiskit open circuit)
	* Chow Wain Sein (aka) Aung Hein `@Chow Wain Sein#4377` :black_nib:
	* Mertcan Abalı `@JackJoyce#6326`
	* Suraj Pratap `@Suraj Pratap#4466` :black_nib:
	* Kaushal Kishor Gagan `@Kaushal Kishor Gagan#1758` :black_nib: :trophy:
	* Alvaro Rafael Gomez `@alvarorgomez#6036` :black_nib:
* SP12_QCA
	* Adarsh Chandrashekar `@Adarsh Chandrashekar#8257`
* SP13_TN
	* Rishi Sreedhar `@Rishi ⟨ he | him ⟩#8336`

:black_nib: - contributions merged

:pencil2: - working on a contribution

:trophy: - major contribution
