**Tasklist**

SP01_readthedocs                                         
* Resource 1: https://readthedocs.org/
* Task 1: make a basic readthedocs with a page with the names of the people working in this project

SP02_ux
* Task 1: try out the Qiskit draw function
* Task 2: devise how to best represent classical logic and quantum gates together. e.g. if (a > 5) H.q[0] else H.q[1]                             

SP03_survey (AIXI/PS/NN)
* Resource 1: https://arxiv.org/abs/1705.10557 [AIXI] 
* Task 1: Summarize the names of the models and their main features.
* Resource 2: http://www.hutter1.net/publ/ksaprob.pdf [AIXI, KSA]
* Task 2: Focus on the KL-KSA model and find out the terms in the policy equation
* Resource 3: https://arxiv.org/pdf/quant-ph/0408063.pdf
* Task 3: Make a short comparison between trace distance and fidelity between quantum density matrices
* Task 4: Replace the entropy with a quantum distance measure and formulate the policy equation of a QKSA based on program length
* Resource 1: https://projectivesimulation.org/ [PS]
* Task 1: Summarize the main features of the PS model.
* Resource 1: https://towardsdatascience.com/the-mostly-complete-chart-of-neural-networks-explained-3fb6f2367464 [ANN]
* Task 1: Compare Boltzmann machine, Hopfield network and Born machines.

SP04_alife (quine hypervisor)
* Resource 1: https://github.com/Advanced-Research-Centre/QKSA/blob/main/v03/quine_003.py
* Task 1: starting from QKSA v3 code, write a wrapper function in Python that would execute quine_003 and then quine_0031 once it is created.
* Resource 2: https://github.com/Advanced-Research-Centre/QKSA/blob/main/v04/quine_004.py
* Task 2: understand what is going on in v04 QKSA code.
* Task 3: augment the hypervisor to handle the QKSA v4 code. This will require taking input from the console, as well as, an agent can keep running event after it reproduces.

SP05_games (tic-tac-toe)
* Task 1: write a Python code that takes in an array of 9 base-3 digits (e.g. 0,1,2, representing blank,cross,dot) and returns an array with an extra cross at a random blank location.
* Task 2: modify the program from Task 1 to take the dot move from the console. The game starts with an empty board. Randomly it selects either the AI or the console for the 1st move. The game ends when all 9 cells are filled (even if you win before). The program stores every set of board transitions that happen (store it in a text file as you can reuse it later).
* Task 3: use the stored set of transitions to search if the current 'partial' board setting was encountered before. Choose the current move based on randomly selecting one of the winning moves from the history. If no history matches, play a random move. (you can also play a random move with some probability even when there are known winning moves to learn other strategies.)

SP06_cworld (grid navigation)
* Resource 1: http://www.hutter1.net/aixijs/demo.html#
* Resource 2: https://github.com/aslanides/aixijs
* Task 1: make an environment in Python similar to the aixijs. Replicate only the KL KSA agent (using as simple a code as possible).
* Resource 3: https://github.com/qic-ibk/projectivesimulation
* Task 2: make an environment in Python similar to the PS (using as simple a code as possible).

SP07_clogic (Boolean logic learning)
* Task 1: given a Boolean function e.g. ((1+2)*!4), where + is OR, * is AND, ! is NOT, compile a quantum circuit with only Toffoli gates
* Task 2: put the inputs into a full superposition (Hadamard on all the qubits) and measure the inputs+output qubits (say for 1000 times) to estimate the truth table. You don't need to measure the ancilla if any.
* Task 3: keep aside the code from task 1/2 for now. Take 2 qubits as input variables, and 1 qubit as a function ID. If the function ID qubit is high, implement a NAND gate between the input qubits (put X-gae on both sides of the two control of a Toffoli gate). Put the input qubits in superposition. Can you predict what is the state of the function qubit from the output?
* Task 4: initialize a quantum circuit on 2 qubits (A,C). Add a Hadamard gate on A and send the quantum circuit object to a Python function. The Python function will do 1 of the 4 possibilities uniformly randomly. Then, add a measure gate on C. From the measurement statistics guess which of the 4 possibilities were added by the Python function. You might not be able to uniquely identify all functions, as it might have the same 0/1 distribution on C.
* Task 5: generalize task 4 to n-input qubits. `n` Boolean inputs will have `2^n` entries in its Truth table. Each entry of the Truth table can have a 0/1 for the output variable C. Thus, there are `2^(2^n)` functions possible. That number grows very fast! Plot how many groups of that function you can identify with your quantum sampling.
* Task 6: instead of an equal superposition on the input qubits, try other circuits to see if you can uniquely identify all functions. Is there such a generalized strategy for n-qubits? :trophy:
* Task 7: among functions that have the same output distribution, in your final answer, return a distribution of the functions within the group inversely weighted by the number of Toffoli gates required to implement the function. i.e. say f1 and f3 cannot be uniquely identified, but f1 requires 2 Toffoli gate, and f2 requires 4 Toffoli gate, return `prob(f1) = 2/(2+4)` and `prob(f2) = 4/(2+4)`
* Task 8: in this task we will systematically form the function based on a input bit-string representing the Godel numbering. Start with all 2-input functions possible using a single Toffoli gate, with the 3rd/target being the output C. The 1st input/control can be either 0/1/A while the 2nd input/control can be either 0/1/B. Thus, `3x3=9` possible encoding is possible, though not all are unique (e.g. if any input is 0, it doesn't matter what the other input is, so all 6 such possibilities basically implement the identity function for the output C).
* Task 9: extend task 8 to 4 Toffoli gate (since we know from the results of Task 7 that with 4 Toffoli gate we can explore all 16 2-input Boolean functions). The input Godel numbering now specifies how the 4 Toffoli gates will be connected and what their inputs will be. 

SP08_least (Pebbling game and E-metric)
* Resource 1: https://arxiv.org/pdf/1904.02121.pdf
* Task 1: read and understand the paper
* Task 2: implement a simple pebbling game on Qiskit as described in the paper
* Resource 1: https://journals.aps.org/prresearch/abstract/10.1103/PhysRevResearch.2.033312
* Task 1: read and understand the paper
* Task 2: given a TM program, find a way to estimate the E-cost
* Task 3: given a Python program (and all memory/time data), find a way to estimate the E-cost

SP09_qThought
* Resource 1: https://github.com/Croydon-Brixton/qthought
* Task 1: code a basic protocol from qthought in Qiskit

SP10_QKSAs (multi-agent QPT)
* Task 1: make a summary of Wigner's friend protocol   
* Task 2: discuss what would happen if Wigner and his friend perform process tomography of their respective system

SP11_QP (qiskit open circuit)
* Task 1: write a function "QP" in Qiskit that creates 2 quantum circuits, each on 1 qubit. Circuit 1 has a Hadamard gate and Measure, Circuit 2 has a Z gate and Measure. If the user calls the function as QP(0), the 1st circuit is executed, if the user calls the function as QP(1), the 2nd circuit is executed.
* Task 2: modify the function "QP" to take 2 arguments, (p,trials). "p" defines the probability with which Circuit 1 is executed, while (1-p) defines the probability for Circuit 2. "trials" refers to the number of times a random number between [0,1] is rolled. If the random number is less than "p", Circuit 1 is executed. The final measurement statistics is returned.
* Task 3: generalize the function "QP" to take 4 inputs: a system size "n"; an array of Qiskit circuit objects each on n-qubits; another array of the same length of probabilities, and the number of trials. The probabilities should add up to 1 or less. Use the uniform random number to select a circuit based on the corresponding probabilities. Add measurement for all n-qubits for all the circuit and aggregate the measurement statistics. For the 1-sum(p), use the identity on all qubits. Test this on 1 qubits for 0.1 prob X gate, 0.1 prob Y gate, 0.1 prob Z gate. Note that this is the model for the depolarizing channel. 
* Task 4: make a general format to store this probabilistic ensemble of circuit in a text file. Also write the program to load the file and parse it into a list of `[[prob1,qcirc_obj1],[prob2,qcirc_obj2]...`.
* Task 5: write a program to take a probabilistic ensemble and return the Choi matrix of the process. For each qcirc_obj, use the Qiskit's [Choi function](https://qiskit.org/documentation/stubs/qiskit.quantum_info.Choi.html) to retrive the process, and the aggregate them based on the probabilities. :trophy:
* Resource 1: https://github.com/Advanced-Research-Centre/QKSA/blob/main/legacy_vers/v12/sandbox/aaqpt.py
* Task 6: write a program to take a Choi matrix and an input density matrix and return the output density matrix. Use this code to test the implementation of task 5 by 1st) individually creating the Choi matrix of the array of circuits, arregating the output density matrix for a input density matrix; 2nd) using the arregated Choi matrix to get the output density matrix; 3rd) comparing they are the same. You can use any input density matrix you wish (e.g. define any 1-qubit quantum circuit and use the qiskit qi package to get the density matrix). Use Resource 1 to understand how a Choi matrix works.
* Task 7: an open QC can also consist of measurement gates. Currently Qiskit does not allow specifying a measurement within a custom gate (to_gate command). Find a way to embed a specified quantum circuit (with measurement gate) as part of a larger quantum circuit. E.g. say a quantum circuit object A consists of 1 qubit and 1 cbit, with a hadamard and a measurement. If A is passed to the function, the function adds a hadamard before A and another measurement after A.

SP12_QCA
* Resource 1: https://github.com/adarsh1chand/Quantum-Cellular-Automata

SP13_TN
* Resource 1: https://www.nature.com/articles/s41534-019-0145-z
