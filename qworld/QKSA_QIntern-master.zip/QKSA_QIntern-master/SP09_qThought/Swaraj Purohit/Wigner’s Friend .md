# Wigner’s Friend Thought Experiment



>   The thought experiment that the physicists of Heriot-Watt University demonstrated is called Wigner’s Friend. It was developed by Eugune Wigner in 1961 when he claimed that a quantum measurement requires a conscious observer, without which nothing ever happens in the universe.



<hr/>  
The scenario involves an indirect observation of a quantum measurement: An observer W observes another observer F who performs a quantum measurement on a physical system. The two observers then formulate a statement about the physical system's state after the measurement according to the laws of quantum theory. However, in most of the interpretations of quantum theory, the resulting statements of the two observers contradict each other. This reflects a seeming incompatibility of two laws in quantum theory: the deterministic and continuous time evolution of the state of a closed system and the nondeterministic, discontinuous collapse of the state of a system upon measurement. Wigner's friend is therefore directly linked to the measurement problem in quantum mechanics with its famous Schrödinger's cat paradox. [from wikipedia.org]

​                                                                                

## Mathematical description

 we use the system $\psi$ system 
$$
\newcommand{\bra}[1]{\left\langle#1\right|}
\newcommand{\ket}[1]{\left|#1\right\rangle}
\newcommand{\bracket}[2]{\ensuremath{\left\langle#1 \vphantom{#2}\right| \left. #2 \vphantom{#1}\right\rangle}}
\newcommand{\matrixel}[3]{\ensuremath{\left\langle #1 \vphantom{#2#3} \right| #2 \left| #3 \vphantom{#1#2} \right\rangle}}

\ket\psi = \alpha \ket0_{\psi}+\beta \ket1_{\psi}
$$

gets measured by Wigner's friend $(F$ ) in the $(|0\rangle_{\psi},|1\rangle_{\psi})$ basis then the probability is $|\alpha|^2$ for $F$ measuring 0 and $|\beta|^2$, for mesuring 1 and for from friends point of view the spin is collapsed into one of its basis states.



Wigner $(W)$ now models the combined system of the spin together with his friend (the joint system is given by the tensor product ${\displaystyle \psi\otimes F}$). He thereby takes a viewpoint outside of ${\displaystyle F}$'s laboratory, which is considered isolated from the environment. Hence, by the laws of quantum mechanics for isolated systems, the state of the whole laboratory evolves unitarily in time. Therefore, the correct description of the state of the joint system as seen from outside is the superposition state

$$
\alpha (|0\rangle _{\psi}\otimes |0\rangle _{F})+\beta (|1\rangle _{\psi}\otimes |1\rangle _{F})
$$

where ${\displaystyle |0\rangle _{F}}$ denotes the state of the friend when they have measured 0, and ${\displaystyle |1\rangle _{F}}$denotes the state of the friend when they have measured 1.

For an initial state ${\displaystyle |0\rangle _{\psi}}$ of $\psi$, the state for ${\displaystyle \psi\otimes F}$ would be ${\displaystyle |0\rangle _{\psi}\otimes |0\rangle _{F}}$ after $F$' s measurement, and for an initial state ${\displaystyle |1\rangle _{\psi}}$, the state of ${\displaystyle \psi\otimes F}$ would be ${\displaystyle |1\rangle _{S}\otimes |1\rangle _{F}}$.Now, by the linearity of Schrödinger's quantum mechanical equations of motion, an initial state ${\displaystyle \alpha |0\rangle _{psi}+\beta |1\rangle _{\psi}}$ for $\psi$ results in the superposition ${\displaystyle \alpha (|0\rangle _{\psi}\otimes |0\rangle _{F})+\beta (|1\rangle _{\psi}\otimes |1\rangle _{F})}$ for ${\displaystyle \psi\otimes F}$



# TL;DR

To visualize Wigner’s Friend, imagine there is a painting in an isolated room. It has two possible states — it is either white (vertical axis of spin) or black (horizontal). Before a person looks at the painting, it is both black and white at the same time.

As soon as the observer measures the photon, it assumes a fixed polarization. However, if another observer is outside of that lab and doesn’t know the result of the measurements, the unmeasured photon will still be in superposition. For this second person, their reality is different from the first one’s reality who had measured the photon. However, none of these conflicting measurements are wrong according to quantum mechanics.

In simpler terms, if John goes into the room with the aforementioned painting and observes it, the painting becomes either white or black. Let’s say that in John’s case he observes the painting to be white. Outside of the room is John’s friend, Chris, who doesn’t know what John has observed when he looked at the painting, so for him the painting is still both black and white at the same time. This means that both John and Chris have a different reality when it comes to the painting.

Wigner was asking, in essence, if there is an objective reality.



<hr/>

# Frauchiger-Renner Argument



The initial state of the $P$  is $\sqrt{\frac{1}{3}} |0\rangle_{P}+\sqrt{\frac{2}{3}} |1\rangle_{P}$

The initial state of $R$ is $|0\rangle_{R}$

The initial state of the relevant subsystems of the agents’ memories is $|0\rangle_{A}, |0\rangle_{B}, |0\rangle_{U}$ and $|0\rangle_{W}$ .

The experiment proceeds as follows:

**t = 1**. Alice measures system $P$ in basis ${|0\rangle_P, |1\rangle_P}$. She records the result in her memory A, 		and prepares $R$ accordingly: if she obtains outcome $a = 0$ she keeps her memory in 		state $|0\rangle_A$ and $R$ in state $|0\rangle_R$; if she obtains outcome $a = 1$ she changes her memory 		to $|1\rangle_A$ and R to $\frac{1}{\sqrt{2}} (|0\rangle_R + |1\rangle_R)$. Thus, first the joint state of $P$ and her memory A 		becomes entangled,
$$
\left(\sqrt{\frac{1}{3}} |0\rangle_{P}+\sqrt{\frac{2}{3}} |1\rangle_{P}\right)|0\rangle_A \rightarrow \sqrt{\frac{1}{3}} |0\rangle_{P}|0\rangle_{A}+\sqrt{\frac{2}{3}} |1\rangle_{P}|1\rangle_{A}
$$


When Alice prepares R, it too becomes entangled with P and A,
$$
\sqrt{\frac{1}{3}} |0\rangle_{P}|0\rangle_{A}|0\rangle_{R}+\sqrt{\frac{2}{3}} |1\rangle_{P}|1\rangle_{A}\frac{1}{\sqrt{2}} (|0\rangle_R + |1\rangle_R)
$$

Alice sends $R$ to Bob

**t = 2.** Bob measures system $R$ in basis $\{|0\rangle_R, |1\rangle_R\}$ and records the outcome b in his 			memory $B$, similarly to Alice. The global state of P, A, R and B becomes
$$
|\psi\rangle_{PARB}=\sqrt{\frac{1}{3}}\left(|0\rangle_{P}|0\rangle_{A}|0\rangle_{R}|0\rangle_{B}+
|1\rangle_{P}|1\rangle_{A}|0\rangle_{R}|0\rangle_{B}+
|1\rangle_{P}|1\rangle_{A}|1\rangle_{R}|1\rangle_{B}\right)
$$
**t = 3.** Ursula measures Alice’s lab (consisting of P and the memory A) in basis  $\{|ok\rangle_{PA}, |fail\rangle_{PA}\}$, where
$$
|ok\rangle_{PA}=\sqrt{\frac{1}{2}}\left(|0\rangle_{P}|0\rangle_{A}+|1\rangle_{P}|1\rangle_{A}\right)
$$

$$
|fail\rangle_{PA}=\sqrt{\frac{1}{2}}\left(|0\rangle_{P}|0\rangle_{A}-|1\rangle_{P}|1\rangle_{A}\right)
$$



![image-20210705183819400](Frauchiger-Renner.png)

t = 4. Wigner measures Bob’s lab (consisting of R and the memory B) in basis $\{|ok\rangle_{RB}, |fail\rangle_{RB}\}$, where
$$
|ok\rangle_{RB}=\sqrt{\frac{1}{2}}\left(|0\rangle_{R}|0\rangle_{B}+|1\rangle_{R}|1\rangle_{B}\right)
$$

$$
|fail\rangle_{RB}=\sqrt{\frac{1}{2}}\left(|0\rangle_{R}|0\rangle_{B}-|1\rangle_{R}|1\rangle_{B}\right)
$$


**t = 5**. Ursula and Wigner compare the outcomes of their measurements. If they were both “ok”, they halt the experiment. Otherwise, they reset the timer and all systems to the initial conditions, and repeat the experiment. If we follow the Born rule, this experiment will at some point halt, as the overlap of the global state at time $t = 2.5$ with $|ok\rangle_{PA}|ok\rangle_{RB}$ gives us a probability of $1/12$. 

It can be shown that since the global state $|ψ\rangle_{PARB}$ can be rewritten as 
$$
\sqrt{\frac{1}{3}}|0\rangle_P|0\rangle_A|0\rangle_R|0\rangle_B + \sqrt{\frac{2}{3}}|1\rangle_p|1\rangle_A|fail\rangle_{RB}
$$
Alice can reason that whenever she finds $P$ in state $|1\rangle_P$, Wigner will obtain outcome “fail” when he measures Bob’s lab. In other words, the inference $“a = 1 \Longrightarrow w = fail”$ can be made. Analogously, one can derive inferences $“b = 1 \Longrightarrow a = 1”$ and $“u = ok \Longrightarrow b = 1”$ made by Bob and Ursula respectively. Together with both Ursula and Wigner eventually obtaining “ok”, chaining these statements leads to a contradiction: given that Wigner got an outcome “ok”, he with certainty predicts that he got outcome “fail”. The description of the thought experiment in terms of agents having different perspectives is shown on Figure above

<hr>





# TL;DR

<img src="https://www.iqoqi-vienna.at/fileadmin/_processed_/2/b/csm_figure_8c2f8be583.jpeg" alt="img"  />

**Two friends, Charlie and Debbie, are isolated in separate laboratories. They each measure one particle from an entangled pair, obtaining the outcomes c and d. Two superobservers, Alice and Bob, are placed outside the laboratories and perform space-like separated measurements with outcomes a and b. They choose either to open the laboratories and read out Charlie’s and Debbie’s outcomes, or to perform large interferometric measurements on the entire laboratories of Charlie and Debbie, respectively. Bong and co-workers [9] showed that the conjunction of three reasonable assumptions — no-superdeterminism (the choices of measurements are independent of the rest of the experiment), locality (the outcomes are independent of the measurement choice in the distant laboratory) and absoluteness of observed events (an observed event is a real single event, and not relative to anything or anyone) — is in contradiction to quantum theoretical predictions and their proof-of-principle experiment. Consequently, at least one of the assumptions is violated in nature**

 **Credit: G. Rubino for Nature Physics**



### **References:**



[1] Wigner, E. P. in *The Scientist Speculates* (ed. Good, I. J.) 284–302 (Heinemann, 1961).

[2] C. Brukner, A no-go theorem for observer-independent facts. [Entropy 20, 5 (2018)](https://www.mdpi.com/1099-4300/20/5/350).

[3] V. Baumann, F. D. Santo, and C. Brukner, Comment on Healey's \Quantum Theory and

the Limits of Objectivity, [Foundations of Physics 49, 741 (2019)](https://link.springer.com/article/10.1007/s10701-019-00276-w).

[4] V. Baumann and S. Wolf, On Formalisms and Interpretations, [Quantum2 (2018)](https://quantum-journal.org/papers/q-2018-10-15-99/).

[5] M. Proietti, A. Pickston, F. Graffitti, P. Barrow, D. Kundys, C. Branciard, M. Ringbauer and A. Fedrizzi, Experimental test of local observer independence, [Science Advances 5, 9 (2019)](https://advances.sciencemag.org/content/5/9/eaaw9832?intcmp=trendmd-adv).

[6] K.W. Bong, A. Utreras-Alarcón, F. Ghafari, Y.C. Liang, N. Tischler, E.G. Cavalcanti, G.J. Pryde and H.M. Wiseman, Testing the reality of Wigner's friend's experience, [arXiv preprint arXiv:1907.05607 (2019).](https://arxiv.org/abs/1902.05080)



[7] V. Baumann and C. Brukner, Wigner’s Friend as a Rational Agent, [Chapter in “Quantum, Probability, Logic”, Springer (2020)](https://link.springer.com/chapter/10.1007/978-3-030-34316-3_4).

[8] V. Baumann, F. Del Santo, A.R.H. Smith, F. Giacomini, E. Ruiz-Castro and C. Brukner, Generalized probability rules from a timeless formulation of Wigner's friend scenarios. [preprint arXiv:1911.09696, 2019](https://arxiv.org/abs/1911.09696).

[9] K. Bong, A. Utreras-Alarcón, F. Ghafari, *et al.* A strong no-go theorem on the Wigner’s friend paradox, [Nat. Phys. (2020)](https://doi.org/10.1038/s41567-020-0990-x).

[10]  C. Brukner, On the quantum measurement problem, [Quantum [Un\]-Speakables II. Springer International Publishing, 95-117 (2017).](https://link.springer.com/chapter/10.1007/978-3-319-38987-5_5)

[11] Jeffrey Bub, Understanding the Frauchiger-Renner Argument https://arxiv.org/abs/2008.08538
