import sys
import os
import time

def load_module(module):

    # module_path = "mypackage.%s" % module
    module_path = module

    if module_path in sys.modules:
        return sys.modules[module_path]

    return __import__(module_path, fromlist=[module])


def wait(file_path):
    time_to_wait = 10
    time_counter = 0
    while not os.path.exists(file_path):
        time.sleep(1)
        time_counter += 1
        if time_counter > time_to_wait:break

    print("done")


def execute(n):

    # current directory path
    directory = os.getcwd()

    i,quine_counter = 0,0

    while (i < len(os.listdir(directory)) and quine_counter<n):

        # sorting the files in the directory
        ordered_files = sorted(os.listdir(directory))
        quine_files = ordered_files[i]

        # print(ordered_files)

        if quine_files.startswith('quine'):

            new = quine_files[:-3]

            # running the quine
            load_module(new)

            # waiting for the quine to replicate
            wait(new+'1.py')
            quine_counter+=1

        i+=1





if __name__ == '__main__':

    # number of quines to be created
    n = 2

    execute(n)
