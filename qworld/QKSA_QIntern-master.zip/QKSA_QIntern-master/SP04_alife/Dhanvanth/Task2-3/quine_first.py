import inspect
import threading as thr
import hypervisor as hype


myName = inspect.getframeinfo(inspect.currentframe()).filename
childCtr = 0
hazardCtr = 0
ageCtr = 0

agents_data = {}

def constructor(p):
    global childCtr
    childCtr += 1
    childName = myName[0:-3]+"c"+str(childCtr)+".py"
    hype.child_threads[childName.split("/")[-1]] = thr.Thread(target=hype.execute,args =(1,childName))
    hype.child_load(childName,hype.child_threads[childName.split("/")[-1]])
    f = open(childName, "w")
    dna = 'import inspect\nimport threading as thr\n\nimport hypervisor as hype\n\nmyName = inspect.getframeinfo(inspect.currentframe()).filename\nchildCtr = 0\nhazardCtr = 0\nageCtr = 0\n\nagents_data = {}\n\ndef constructor(p):\n\tglobal childCtr\n\tchildCtr += 1\n\tchildName = myName[0:-3]+"c"+str(childCtr)+".py"\n\thype.child_threads[childName.split("/")[-1]] = thr.Thread(target=hype.execute,args =(1,childName))\n\thype.child_load(childName,hype.child_threads[childName.split("/")[-1]])\n\tf = open(childName, "w")\n\tdna = %r\n\tf.write(dna%%(dna,p))\n\tf.close()\n\ndef goedel_machine():\n\tprediction = str(%r)\n\tglobal ageCtr, childCtr, hazardCtr, agents_data\n\twhile hazardCtr < 3:\n\t\tageCtr += 1\n\t\tagents_data[ageCtr] = []\n\t\tp = input("{} Running now\\nPerceive Environment: ".format(myName.split("/")[-1]))\n\t\tif p=="stop":\n\t\t\thype.flag = 0\n\t\t\tbreak\n\t\treward = 3\n\t\tfor (i,j) in zip(prediction,p):\n\t\t\tif i!=j:\n\t\t\t\treward -= 1\n\t\tagents_data[ageCtr].append(reward)\n\t\tif reward == 0:\n\t\t\tconstructor(p)\n\t\t\tagents_data[childCtr] = []\n\t\t\thazardCtr += 1\n\t\tprint("Agents: {} ; Children: {} ; Hazard: {} ;\\n".format(ageCtr,childCtr,hazardCtr))\n\tquineId = myName.split("/")[-1]\n\thype.age_threads[quineId] = agents_data\n\ngoedel_machine()\nhype.display()\nif hype.flag:\n\thype.child_pop()'
    f.write(dna%(dna,p))
    f.close()

def goedel_machine():
    prediction = str('000')
    global ageCtr, childCtr, hazardCtr, agents_data
    while hazardCtr < 3:
        ageCtr += 1
        agents_data[ageCtr] = []
        p = input("{} Running now\nPerceive Environment: ".format(myName.split("/")[-1]))
        
        # Enter stop to terminate process
        if p=="stop":
            hype.flag = 0
            break
        reward = 3
        for (i,j) in zip(prediction,p):
            if i!=j:
                reward -= 1

        agents_data[ageCtr].append(reward)

        if reward == 0:
            constructor(p)
            hazardCtr += 1

        print("Agents: {} ; Children: {} ; Hazard: {} ;\n".format(ageCtr,childCtr,hazardCtr))

    quineId = myName.split('/')[-1]
    hype.age_threads[quineId] = agents_data

if __name__ == '__main__':

    hype.create()
    goedel_machine()
    hype.display()
    if hype.flag:
        hype.child_pop()
