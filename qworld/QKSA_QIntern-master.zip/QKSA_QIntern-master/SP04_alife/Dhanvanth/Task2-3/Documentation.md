**Task: Designing Quine Hypervisor**


**Description:** 
* "Quine_first.py" will initiate the evolution sequence.
* The list of agents and quine children will be stored in a dictionary in the "hypervisor.py"
* "Hypervisor.py" has other methods for initiating various threads created during evolution.
* As of now the quines will evolve one at a time as we'll be manually giving inputs to agents. So we'll be doing a level order traversal in the graph shown below. This can be modified later.
* The evolution will be slower as the number of quines increase and to optimize for handling a large number of threads I'm planning to use a threadExecutor. So, this optimization is yet to done.
* Entering "stop" when asked for input will terminate the process and wait for a few seconds to terminate the created threads.


**Evolution:**  
```
                
q *──────*qc1───────*qc1qc1
    │           │
    │           │   
    │           └───*qc1qc2
    │           │
    │           │   
    │           └───*qc1qc3
    │
    │
    └───*qc2────────*qc2qc1
    │           │
    │           │   
    │           └───*qc2qc2
    │           │
    │           │   
    │           └───*qc2qc3
    │
    │
    └───*qc3────────*qc3qc1
                │
                │   
                └───*qc3qc2
                │
                │   
                └───*qc3qc3
```