import threading as thr
import sys
import os
import time
from collections import deque
global age_threads, child_threads, queue, flag


def create():
    global age_threads, child_threads, queue, flag

    # threads for agents
    age_threads = {}

    # threads for created quine children
    child_threads = {}

    # flag to terminate all processes
    flag = 1

    # Queue containing threads that are yet to be started
    queue = deque()

def display():
    global age_threads, child_threads, queue

    # Display summary of Quines created
    print('\n*********\n\nAgents List:\n {}\n\nChildren:\n{}\n\nChild Queue: \n{}\n\n*********\n'.format(age_threads,child_threads,queue))

# A future function yet to be implemented for optimizing evolution
def threadPool(tasks):

    with ThreadPoolExecutor(max_workers=3) as executor:
        future = executor.submit(load_module, )

def load_module(module):

    # module_path = "mypackage.%s" % module
    module_path = module

    if module_path in sys.modules:
        return sys.modules[module_path]

    return __import__(module_path, fromlist=[module])

def wait(file_path):
    time_to_wait = 10
    time_counter = 0
    while not os.path.exists(file_path):
        time.sleep(1)
        time_counter += 1
        if time_counter > time_to_wait:break

    # print("done ",file_path)

def execute(n,fileName):

    # current directory path
    directory = os.getcwd()

    i,quine_counter = 0,0

    fileName = fileName.split("/")[-1]

    while (i < len(os.listdir(directory)) and quine_counter<n):

        # sorting the files in the directory
        # ordered_files = sorted(os.listdir(directory))
        # quine_file = ordered_files[i]
        quine_file = fileName

        # print(ordered_files)

        if quine_file.startswith('quine_firstc'):

            new = quine_file[:-3]
            print("File to be loaded: %s" % new)
            
            # running the quine
            load_module(new)

            # waiting for the quine to replicate
            wait(new+'c.py')
            quine_counter+=1

        i+=1

def child_load(filePath,a):
    # loading the newly created threads
    queue.append((filePath,a))

def child_pop():
    # To execute the created quine children
    global queue
    if len(queue)!=0:
        path, t = queue.popleft()
        wait(path)
        t.start()
    else:
        print("Queue Empty")
