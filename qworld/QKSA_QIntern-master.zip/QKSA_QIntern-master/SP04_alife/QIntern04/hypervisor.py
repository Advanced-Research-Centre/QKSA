'''
Code developed as part of QWorld QIntern 2021
Developer: Dhanvanth Balakrishnan & Aritra Sarkar
'''

from collections import deque
import importlib

biosphere = []															# Agents currently running
agt_waitlist = deque()													# Queue containing agents that are created but yet to be executed
run_log = []															# Agents which have already executed and died
abort = 0																# Flag to terminate all processes
max_thread = 2															# How many agents can be handled in parallel by the hypervisor threads

agt_waitlist.append("quine_004")

while (len(biosphere) + len(agt_waitlist) > 0):							# No agents alive, every agent serviced!

	print("\nStatus --- Running:",biosphere," Waitlist:",list(agt_waitlist)," Dead:",run_log)
	
	abort = int(input("Abort [1/Enter]?:") or 0)
	if abort == 1:														# User gets to choose each cycle (world clock tick) to abort or continue
		break
	
	if len(biosphere) < max_thread and len(agt_waitlist) > 0:			# If biosphere can support more agents, bring one alive from the waitlist
		agtName = agt_waitlist.popleft()
		agtClass = getattr(importlib.import_module(agtName), "agent")	# Filename changes for each quine while class name remains same
		agtObj = agtClass()												# Agent gets instantiated here
		biosphere.append([agtName,agtObj])
		
	for agt in biosphere:
		print("Running agent:",agt[0])
		reportChild = agt[1].runStep()									# Run one perception cycle for the agent
		if agt[1].hazardCtr == 3:										# If enough hazard has been encountered
			run_log.append(agt[0])
			biosphere.remove(agt)
		if len(reportChild) > 0:										# If agent reproduced in this cycle add child to the waitlist
			agt_waitlist.append(reportChild[0:-3])
				
print("Final Status --- Running:",biosphere," Waitlist:",list(agt_waitlist)," Dead:",run_log)