'''
Code developed as part of QWorld QIntern 2021
Developer: Dhanvanth Balakrishnan & Aritra Sarkar
'''

import inspect
import time

class agent:

	myName = inspect.getframeinfo(inspect.currentframe()).filename
	childCtr = 0
	hazardCtr = 0
	ageCtr = 0
	prediction = str('000')

	def reproduce(self, p):
		self.childCtr += 1
		childName = self.myName[0:-3]+"c"+str(self.childCtr)+".py"
		f = open(childName, "w")
		dna='\
import inspect\n\
import time\n\
\n\
class agent:\n\
\n\
\tmyName = inspect.getframeinfo(inspect.currentframe()).filename\n\
\tchildCtr = 0\n\
\thazardCtr = 0\n\
\tageCtr = 0\n\
\tprediction = str(%r)\n\
\t\n\
\tdef reproduce(self, p):\n\
\t\tself.childCtr += 1\n\
\t\tchildName = self.myName[0:-3]+"c"+str(self.childCtr)+".py"\n\
\t\tf = open(childName, "w")\n\
\t\tdna=%r\n\
\t\tf.write(dna%%(p,dna))\n\
\t\tf.close()\n\
\t\ttime.sleep(2)\n\
\t\treturn childName.split("\\\\")[-1]\n\
\t\n\
\tdef runStep(self):\n\
\t\treportChild = ""\n\
\t\tif self.hazardCtr < 3:\n\
\t\t\tself.ageCtr += 1\n\
\t\t\tp = input("Perceive Environment: ")\n\
\t\t\treward = 3\n\
\t\t\tfor (i,j) in zip(self.prediction,p):\n\
\t\t\t\tif i!=j:\n\
\t\t\t\t\treward -= 1\n\
\t\t\tif reward == 0:\n\
\t\t\t\treportChild = self.reproduce(p)\n\
\t\t\t\tself.hazardCtr += 1\n\
\t\treturn reportChild'
		f.write(dna%(p,dna))
		f.close()
		time.sleep(2)
		return childName.split("\\")[-1]

	def runStep(self):
		reportChild = ""
		if self.hazardCtr < 3:
			self.ageCtr += 1
			p = input("Perceive Environment: ")
			reward = 3
			for (i,j) in zip(self.prediction,p):
				if i!=j:
					reward -= 1
			if reward == 0:
				reportChild = self.reproduce(p)
				self.hazardCtr += 1
		#print("Agent Status:",self.ageCtr,self.childCtr,self.hazardCtr)
		return reportChild