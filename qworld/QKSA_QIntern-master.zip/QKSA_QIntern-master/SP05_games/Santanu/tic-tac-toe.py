import random

print('Enter the state of the Tic-Tac-Toe board')
print('0 represents Blank Space')
print('1 represents Cross')
print('2 represents Dot')

a = [None] * 9

for i in range(0, 9):
    print('Enter element', i+1, ':-')
    element = int(input())
    while element not in [0, 1, 2]:
        print("Invalid input! Please choose from 0, 1 or 2")
        element = int(input())
    a[i] = element

print('Current state of board')
print(a)

random_mark = random.randint(0, 8)
while a[random_mark] != 0:
    random_mark = random.randint(0, 8)

a[random_mark] = 1

print('State after random cross marking')
print(a)
