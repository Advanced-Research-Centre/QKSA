print("TIC-TAC-TOE") #Terminology
print("0 - Blank")   
print("1 - Cross")
print("2 - Dot")
import random 
arr = [] #Empty array
ind = []
print("\nEnter 9 elements") #Entering the 9 elements for tic=tac-toe
c = 0 #Counter variable
for i in range(0,9):
    x = int(input())
    if x<=2 and x>=0: #Ensuring that the elements entered are only 0,1 or 2
        arr.append(x) #Appending each value to the empty array
        if x==0:
            c+=1 #Counts the no. of blanks(0) in the array
            ind.append(i) #An array that takes care of the indexes of 0(blanks)
    else:
        print("Enter a number from 0-2 only")
        x=int(input()) #Even if you enter an element other than 0,1 or 2 you get a chance to re-enter it
        
print("Initial = ",arr) #Initial array
r = random.randint(0,c-1) #Function that gives a random no for the no. of zeros in counter
arr[ind[r]] = 1 #Putting an extra cross by using the index of 0 in array 'ind'
print("Final state with a random extra cross = ",arr)