print("TIC-TAC-TOE") #Terminology
print("0 - Blank")   
print("1 - Cross")
print("2 - Dot")
import random 
arr = [] #Empty array
print("\nEnter 9 elements") #Entering the 9 elements for tic=tac-toe
for i in range(0,9):
    x = int(input())
    if x<=2 and x>=0: #Ensuring that the elements entered are only 0,1 or 2
        arr.append(x) #Appending each value to the empty array
    else:
        print("Enter a number from 0-2 only")
        x=int(input()) #Even if you enter an element other than 0,1 or 2 you get a chance to re-enter it
        
print("Initial = ",arr) #Initial array
r = random.randint(0,9)  
while arr[r-1] !=0: #Checking whether the random number has a blank space 
    r = random.randint(0,9) #If not blank state(0) then find another value with random
arr[r-1] = 1 #Changing 0 with 1
print("Final state with a random extra cross = ",arr)