print("TIC-TAC-TOE") #Terminology
print("0 - Blank")   
print("1 - Cross")
print("2 - Dot\n")

board = ["0","0","0", #Variable for the empty(default) board
         "0","0","0",
         "0","0","0"]
import random
player1 = " " #Player 1
player2 = " " #Player 2

#Function to display Tic-Tac-Toe board
def display_board():
    print(board[0] + "|" + board[1] + "|" + board[2])
    print(board[3] + "|" + board[4] + "|" + board[5])
    print(board[6] + "|" + board[7] + "|" + board[8])
display_board() #Shows the empty board first

def handle_element(ele): #Function to fill in the cross(1) or dot(2) in the tic-tac-toe board
    board[position-1] = str(ele)
    display_board()
    return

def board_transitions(i,ele,pos): #Function to write the contents of every move in a file
    f = open("tic-tac-toe.txt","a") #Appends every transition to a file
    f.write("Player "+str(i)+" played "+str(ele)+" at position "+str(pos)+"\n") 
    f.close()
    return

chance = random.randint(1,2) #Finding the first chance randomly between 2 players

#If Player 1 is first
if chance == 1:
    for i in range(1,10):
            if i%2==1:
                position = int(input("Player 1 choose a position from 1-9:")) #Selecting a position on a board to fill in the cross(1)/dot(2)
                board_transitions(1,1,position) #Writing the content to tic-tac-toe.txt
                handle_element(1) #Traditionally the first player starts with a cross(1)
            else:
                position = int(input("Player 2 choose a position from 1-9:"))
                board_transitions(2,2,position)
                handle_element(2)
                
#If Player 2 is first
elif chance == 2:
    for i in range(2,11):
            if i%2==0:
                position = int(input("Player 2 choose a position from 1-9:"))
                board_transitions(2,1,position)
                handle_element(1)
                
            else:
                position = int(input("Player 1 choose a position from 1-9:"))
                board_transitions(1,2,position)
                handle_element(2)